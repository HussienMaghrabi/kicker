<?php
use Illuminate\Http\Request;

Route::post('notification','ReceivedprojectController@receive');