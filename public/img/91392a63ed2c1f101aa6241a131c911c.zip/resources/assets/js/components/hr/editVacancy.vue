<template>
    <section class="container jobs">
       <b>Edit Vacancy</b><hr>
       <div class="column is-mobile">
           <div class="column is-12">
               <b><label style="display:block">English Name: </label></b>
               <b-input type="text" v-model="vacancy.en_name"></b-input>
           </div>

        <div class="column is-12">
            <b><label style="display:block">Arabic Name: </label></b>
            <b-input type="text" v-model="vacancy.ar_name"></b-input>
        </div>

       </div>

        <div class="column is-mobile">
           <div class="column is-12">
                <b-field label="English Description:">
                    <b-input type="textarea" v-model="vacancy.en_description"></b-input>
                </b-field>  
           </div>

            <div class="column is-12">
                <b-field label="Arabic Description:">
                        <b-input type="textarea" v-model="vacancy.ar_description"></b-input>
                </b-field>      
            </div>
       </div>
        

        <div class="column is-mobile is-12" style="display:inline-flex;margin-bottom:2%;">
            <div class="column is-4">
                <b-field label="Job Title">
                         <b-select expanded v-model="vacancy.job_title_id">
                            <option v-for="jobTitle in jobTitles" :value="jobTitle.id" >
                                    {{ jobTitle.en_name }} 
                            </option>
                       </b-select>
                </b-field> 
            </div>

            <div class="column is-4">
                <b-field label="Status">
                        <b-select expanded v-model="vacancy.status">
                            <option value="0">Open</option>
                            <option value="1">Closed</option>
                        </b-select>
                </b-field> 
            </div>

            <div class="column is-4">
                <b-field label="Type">
                        <b-select expanded v-model="vacancy.type">
                            <option value="freelance">freelance</option>
                            <option value="part_time">Part Time</option>
                            <option value="full_time">Full Time</option>
                        </b-select>
                </b-field> 
            </div>
        </div> 

        <b-button @click="updateForm" type="is-success" icon-right="pen"> Edit </b-button>
    
 
    </section>
</template>
<style>
.jobs{
    background: #fff;
    padding-left: 2%;
    padding-bottom: 1%;
}
.control
{
    width: 50%;
}
</style>
<script>
import {editVacancy,getVacancyInputs,showVacancy} from './../../calls'

export default {
    data() {
            return {
                job_title_id: null,
                jobTitles:[],
                vacancy:{},
                status:null,
                type:null,
                open:'0',
                close:'1',
                token: window.auth_user.csrf
            }},
    created() {
        this.id = this.$route.params.id
    },
    mounted() {
        this.getData()
        this.getRowData()
    },
 methods: {
    getRowData(){
        this.isLoading = true
            showVacancy(this.id).then(response=>{
                console.log(response)
            this.vacancy = response.data.vacancy
            this.jobTitle = response.data.JobTitle
            this.isLoading = false
            })
        .catch(error => {
            console.log(error)
        })
    },
    getData(){
            this.isLoading = true
            getVacancyInputs().then(response=>{
                console.log(response)
                this.jobTitles = response.data
            })
            .catch(error => {
                console.log(error)
            })
            this.isLoading = false
    },
    updateForm(){
            const bodyFormData = new FormData();
            for (let key in this.vacancy) {
                const value = this.vacancy[key];
                bodyFormData.set(key, value);
            }
            bodyFormData.append('_method','put')
            editVacancy(bodyFormData,this.id).then(response=>{
                console.log(response)
                $(location).attr('href', '/admin/vue/vacancy')
            }).catch(error=>{
                console.log(error)
            })
    }},
}
</script>
