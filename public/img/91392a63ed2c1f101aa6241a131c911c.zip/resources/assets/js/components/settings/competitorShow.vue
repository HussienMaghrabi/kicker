<template>
    <section class="container competitors">
       <h3>Competitors</h3><hr>
       <div class="column first">
           <div class="is-4">
               <b><label>Arabic Name: </label></b>
           </div>
           <hr>
             <div class="is-4">
               <b><label>Notes: </label></b>
           </div>
           <hr>
       </div>

        <div class="column second">
           <div class="is-6">
               <b><label>English Name: </label></b>
           </div>
           <hr>
           <div class="is-6">
               <b><label>Facebook: </label></b>
           </div>
           <hr>
       </div>
 
    </section>
</template>
<style>
.competitors{
    background: #fff;
    padding-left: 2%;
}
</style>
<script>
export default {
    
}
</script>
