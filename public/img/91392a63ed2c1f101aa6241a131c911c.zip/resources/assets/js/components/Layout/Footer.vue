<template>
    <footer class="footer">
        <div class="content has-text-centered">
            <p>
            <strong> &copy; 2019 Propertz CRM All Rights Reserved.</strong>
            <small class="text-center">version 1.5</small>
            </p>
        </div>
    </footer>
</template>

<script>
export default {
    
}
</script>
