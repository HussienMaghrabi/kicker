export default {
	lead: 'العملاء',
	inventory: 'المخزون',
	marketing: 'التسويق',
	proposals: 'اقتراحات',
	'closed-deals': 'الاتفاقات المغلقة',
	'hr': 'الموارد البشرية',
	'finances': 'المليات',
	'reports': 'التقارير',

}