@extends('admin.index')

@section('content')
@include('admin.leads.cil')
@endsection