@include('website.nav')
@yield('content')
@include('website.footer')
